package com.example.testfile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class showMessageActivity extends AppCompatActivity {

    private TextView tv_allmsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_message);

        tv_allmsg = (TextView) findViewById(R.id.tv_allmsg);
    }

    @Override
    protected void onStart() {
        super.onStart();
        this.loadAllMessages();
    }

    public void loadAllMessages(){
        File path = new File(this.getFilesDir(), "history");
        File file = new File(path, MainActivity.FILENAME);

        try{
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line = null;
            while ((line = bufferedReader.readLine()) != null){
                tv_allmsg.append(line+"\n");
            }
            bufferedReader.close();
            fileReader.close();
        } catch (FileNotFoundException e){
            Toast.makeText(this, "File problem:\n"+e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (IOException e){
            Toast.makeText(this, "IO problem:\n"+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
