package com.example.testfile;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private EditText et_message;
    public static final String FILENAME = "messages.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_message = (EditText) findViewById(R.id.et_message);
    }


    public File getFile(){
        File path = new File(this.getFilesDir(),"history");
        if(!path.exists() && !path.mkdirs()){
            Toast.makeText(this, "Failed to create path!!", Toast.LENGTH_SHORT).show();
            return null;
        }
        File file = new File(path, FILENAME);
        return file ;
    }

    public void onClickSave(View view){
        File file = getFile();
        if(file!=null){
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file, true);
                byte[] msg = (et_message.getText().toString()+"\n").getBytes();
                fileOutputStream.write(msg);
                fileOutputStream.close();
                et_message.setText("");
            } catch (FileNotFoundException e) {
                Toast.makeText(this, "File problem:\n"+ e.getMessage(), Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(this, "Write problem:\n"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onClickSee(View view){
        Intent intent = new Intent(this, showMessageActivity.class);
        startActivity(intent);
    }
}
